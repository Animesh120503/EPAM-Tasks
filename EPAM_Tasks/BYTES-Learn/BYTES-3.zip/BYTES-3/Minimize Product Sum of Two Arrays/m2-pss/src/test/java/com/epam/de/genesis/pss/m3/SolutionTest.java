package com.epam.de.genesis.pss.m3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SolutionTest {
    private Solution solution;
    @BeforeEach
    void setUp() {
        solution = new Solution();
    }

    @Test
    public void testWithInvalidData(){
        assertEquals(0, solution.deepestLeavesSum(null));
    }

}