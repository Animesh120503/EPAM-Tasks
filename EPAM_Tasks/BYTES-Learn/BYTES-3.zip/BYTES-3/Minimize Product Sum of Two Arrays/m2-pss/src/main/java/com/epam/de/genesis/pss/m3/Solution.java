package com.epam.de.genesis.pss.m3;
import java.util.*;

public class Solution {
    public int deepestLeavesSum(TreeNode root) {
        if(root == null)
            return 0;

        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);

        int sum = 0;
        while (!queue.isEmpty()) {
            sum = 0;
            for (int size = queue.size(); size > 0; --size) {
                TreeNode currentNode = queue.poll();
                sum += currentNode.getValue();
                if (currentNode.getLeft() != null) {
                    queue.offer(currentNode.getLeft());
                }
                if (currentNode.getRight() != null) {
                    queue.offer(currentNode.getRight());
                }
            }
        }
        return sum;
    }
}
